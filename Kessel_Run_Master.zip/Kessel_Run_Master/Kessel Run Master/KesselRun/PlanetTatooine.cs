﻿using System;

namespace KesselRun
{
    class PlanetTatooine
    {
        
        public static bool greedoBool;
        public static bool darkMatterBool;
        public static void RunPlanetTatooine()
        {
            try
            {
                Intro.RunIntro(); // RUNS INTRO STORY TEXT
                //SET NECESSARY EVENT VALUES TO FALSE
                greedoBool = false;
                darkMatterBool = false;
                do
                {
                    MainMenu.RunMainMenu();
                }
                while (greedoBool == false || darkMatterBool == false);
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        public static void RunNextPlanet()
        {
            Program program = new Program();
            LucasPlanet lucasplanet = new LucasPlanet();

            program.LoadScreen();
            program.currentPlanet = 2;
            lucasplanet.runLucasPlanet();
            Console.Clear();
        }
    }
}