﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms;

namespace KesselRun
{
    class Stevenidium
    {
        static KRController kr = new KRController();
        static int score = 0;
        static int nextParts = 10;
        public static void Typewrite(string message, int lagtime)
        {
            for (int i = 0; i < message.Length; i++)
            {
                //Cursor.Hide();
                Console.Write(message[i]);
                System.Threading.Thread.Sleep(lagtime);
                //Cursor.Show();

            }
        }
        public void RunStevenidium()
        {
            ConsoleKeyInfo key;

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Typewrite("Your ship is breaking down and you have to land.\n", 70);
            Typewrite("You arrive on Stevenidium 5XXTentacion.\n", 70);
            Typewrite("This planet is known for being riddled with ruthless space pirates.\n", 70);
            Typewrite("The type of scum that would murder a child for a single stonk.\n", 70);
            Typewrite("However, the pirates do have the five parts you need to repair your ship.\n", 70);
            Typewrite("Let's get hunting.\n", 70);
            Console.ForegroundColor = ConsoleColor.White;

            do
            {
                Console.WriteLine();
                Console.WriteLine("1 = Look Around, 2 = Attack, 3 = Trade");
                Console.Write("Dark Matter [" + score + "] Parts [" + kr.GetParts() +
                    "] Action [1,2,3]: ");

                key = Console.ReadKey();

                Console.WriteLine();

                DoAction(key.Key);
            }
            while (key.Key != ConsoleKey.Q && kr.GetParts() < 5);

            if (kr.GetParts() >= 5)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Typewrite("You acquired the five parts you need to repair your ship!\n", 70);
                Typewrite("You repaired your ship with the help of Chewie.\n" +
                "Time to depart for the next planet and adventure!", 70);
                Console.ForegroundColor = ConsoleColor.White;
                RunNextPlanet();
            }

            Console.ReadKey();
        }
        static void DoAction(ConsoleKey key)
        {
            if (key == ConsoleKey.D1 || key == ConsoleKey.NumPad1)
            {
                int points = kr.Explore();
                if (points > 0)
                {
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine("You gain " + points + " dark matter!");
                    score += points;
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            else if (key == ConsoleKey.D2 || key == ConsoleKey.NumPad2)
            {
                int rounds = kr.Battle();
                if (rounds > 0)
                {
                    int points = 10 - rounds;
                    if (points < 0)
                    {
                        points = 0;
                    }

                    score += points;

                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine("You gain " + points + " dark matter!");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            else if (key == ConsoleKey.D3 || key == ConsoleKey.NumPad3)
            {
                Console.WriteLine(kr.Trade());
                
                if (score >= 10)
                {
                    kr.SetParts(kr.GetParts() + 1);
                    nextParts = kr.GetParts() * 10;
                    score -= 10;

                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine(
                    "You've traded 10 dark matter for another part needed to repair your ship!" +
                    " Parts: " + kr.GetParts());
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Looks like you don't have my asking price, Fella!");
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }
        static void RunNextPlanet()
        {
            Program program = new Program();
            Hoth daveplanet = new Hoth();

            program.LoadScreen();
            program.currentPlanet = 5;
            daveplanet.RunHoth();
            Console.Clear();
        }
    }
    public interface IState
    {
        int Explore();
        int Battle(int parts);
        string Trade();
    }
    public class TradeState : IState
    {
        private KRController context;
        public TradeState(KRController context)
        {
            this.context = context;
        }
        public string Trade()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            return "Welcome to Lamarr's Laundered Goods. I'm Lamarr!\n" +
            "Due to the space pirate's, I only deal in dark matter here.\n" +
            "The pirates know what credits are, " +
            "but they're too dumb to know what dark matter is used for.\n" +
            "My ship isn't in as rough a shape as yours, but I'm low on fuel.\n" +
            "I'm trying to get off this forsaken cesspool too.\n" +
            "Let's help each other out, Fella!\n" +
            "I'll do 1 part for 10 dark matter. Take it or leave it!\n";
            
        }

        public int Explore()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("You look around for space pirates to slay.");
            Console.ForegroundColor = ConsoleColor.White;

            int ran = RandomGenerator.GetRandomNumber(5);
            if (ran == 0)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("A space pirate approaches! Prepare for battle!");
                Console.ForegroundColor = ConsoleColor.White;
                context.SetState(context.GetBattleState());
            }
            else if (ran == 1)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("You find some dark matter behind a tree!");
                Console.ForegroundColor = ConsoleColor.White;
                return 2;
            }

            return 0;
        }
        public int Battle(int parts)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("You find no space pirates.");
            Console.ForegroundColor = ConsoleColor.White;
            return 0;
        }
    }
    public class ExploreState : IState
    {
        private KRController context;

        public ExploreState(KRController context)
        {
            this.context = context;
        }

        public int Explore()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("You look around for space pirates to slay.");
            Console.ForegroundColor = ConsoleColor.White;

            int ran = RandomGenerator.GetRandomNumber(5);
            if (ran == 0)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("A space pirate approaches! Prepare for battle!");
                Console.ForegroundColor = ConsoleColor.White;
                context.SetState(context.GetBattleState());
            }
            else if (ran == 1)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("You find some dark matter behind a tree!");
                Console.ForegroundColor = ConsoleColor.White;
                return 2;
            }

            return 0;
        }

        public int Battle(int parts)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("You find no space pirates.");
            Console.ForegroundColor = ConsoleColor.White;
            return 0;
        }
        public string Trade()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            return "Welcome to Lamarr's Laundered Goods. I'm Lamarr!\n" +
            "Due to the space pirates, I only deal in dark matter here.\n" +
            "The pirates know what credits are, " +
            "but they're too dumb to know what dark matter is used for.\n" +
            "My ship isn't in as rough a shape as yours, but I'm low on fuel.\n" +
            "I'm trying to get off this forsaken cesspool too.\n" +
            "Let's help each other out, Fella!\n" +
            "I'll do 1 part for 10 dark matter. Take it or leave it!\n";
        }
    }
    public class BattleState : IState
    {
        private KRController context;
        private int rounds = 0;

        public BattleState(KRController context)
        {
            this.context = context;
        }


        public int Explore()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("You look around but can't see anything around " +
            "the space pirate's ugly mug!");
            Console.ForegroundColor = ConsoleColor.White;
            return 0;
        }

        
        public int Battle(int parts)
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.Write("You try to slay the space pirate... ");
            Console.ForegroundColor = ConsoleColor.White;

            rounds++;

            System.Threading.Thread.Sleep(1000);

            int maxRan = 10 - parts;
            if (maxRan < 1)
            {
                maxRan = 1;
            }

            int ran = RandomGenerator.GetRandomNumber(maxRan);
            if (ran == 0)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("the pirate(rebel) scum is dead!");
                Console.ForegroundColor = ConsoleColor.White;
                context.SetState(context.GetExploreState());

                int tempRounds = rounds;
                rounds = 0;

                return tempRounds;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("but fail.");
                Console.ForegroundColor = ConsoleColor.White;
            }

            if (rounds >= 9)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("You flee out of fear.");
                Console.ForegroundColor = ConsoleColor.White;
                context.SetState(context.GetExploreState());

                rounds = 0;
            }

            return 0;
        }
        public string Trade()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            return "I'm a pirate, but yeah I like to trade, Fella!\n" +
            "LaMarr thinks all pirates are too stupid to know what dark matter does.\n" +
            "I'm not your average pirate though, Fella!\n" +
            "I'll do 1 part for 10 dark matter. Take it or leave it!\n";
        }
    }
    
    public class KRController
    {
        private IState exploreState;
        private IState battleState;
        private IState tradeState;
        private IState state;
        private int parts = 0;

        public KRController()
        {
            exploreState = new ExploreState(this);
            battleState = new BattleState(this);
            tradeState = new TradeState(this);

            state = exploreState;
        }

        public int Explore()
        {
            return state.Explore();
        }

        public int Battle()
        {
            return state.Battle(parts);
        }
        public string Trade()
        {
            return state.Trade();
        }

        public void SetState(IState state)
        {
            this.state = state;
        }

        public void SetParts(int parts)
        {
            this.parts = parts;
        }

        public int GetParts()
        {
            return parts;
        }

        public IState GetExploreState()
        {
            return exploreState;
        }

        public IState GetBattleState()
        {
            return battleState;
        }
    }
    public static class RandomGenerator
    {
        private static Random random = new Random();

        public static int GetRandomNumber(int maxValue)
        {
            return random.Next(maxValue);
        }
    }
}
