﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;

namespace KesselRun
{
    class Program
    {
        public int currentPlanet = 0;

        static void Main(string[] args)
        {
            

            Program program = new Program();
            LucasPlanet lucasplanet = new LucasPlanet();
            ChadPlanet chadplanet = new ChadPlanet();
            PlanetTatooine everettplanet = new PlanetTatooine();

            Console.WriteLine("Please press ENTER to load \"THE KESSEL RUN\".");
            Console.ReadLine();
            Console.Clear();

            StartMenue();

            program.LoadScreen();
            program.currentPlanet = 1;
            PlanetTatooine.RunPlanetTatooine(); //EVERETT PLANET
            Console.Clear();
        } 
        
        public void Typewrite(string message, int speed)
        {
            for (int i = 0; i < message.Length; i++)
            {
                Console.Write(message[i]);
                System.Threading.Thread.Sleep(speed);
            }
        }

        public void EndCredits()
        {
            Program program = new Program();
            Console.ForegroundColor = ConsoleColor.White;
            program.Typewrite("---THE KESSEL RUN---", 100);

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            program.Typewrite("\n\nSTEVEN \"Steve-O\" BAINTER", 100);
            Console.ForegroundColor = ConsoleColor.Magenta;
            program.Typewrite("\nEVERETT \"Big-E\" DAVIS", 100);
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            program.Typewrite("\nLUCAS \"LaMarr\" SMITH", 100);
            Console.ForegroundColor = ConsoleColor.Red;
            program.Typewrite("\nCHAD \"Chaddars\" CHRISTY", 100);
            Console.ForegroundColor = ConsoleColor.Cyan;
            program.Typewrite("\nDAVID \"D-Lo\" DEL OLMO\n", 100);
            Console.ReadLine();
            Environment.Exit(0);
        }
        
        public static void StartMenue()

        {
            Program program = new Program();

            bool checkAgain = true;

            do
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.SetCursorPosition(70,0);
                program.Typewrite("---THE KESSEL RUN---\n\n", 100);
                Console.WriteLine("                                                                           1. START");
                Console.WriteLine("                                                                           2. QUIT\n");            
                Console.WriteLine("                                                                           CHOICE: ");
                Console.SetCursorPosition(83,5);

                string choice = Console.ReadLine();
                Console.Clear();

                if (choice == "1")
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.SetCursorPosition(80,8);
                    program.Typewrite("WELCOME", 150);
                    checkAgain = false;
                    Console.ReadLine();
                    Console.Clear();
                }
                else if (choice == "2")
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.SetCursorPosition(80,8);
                    program.Typewrite("GOODBYE", 100);
                    checkAgain = false;
                    Console.ReadLine();
                }
                else
                {
                    Console.SetCursorPosition(70,8);
                    Console.WriteLine("Please provide a valid input...");
                    Console.ReadLine();
                    Console.Clear();
                    checkAgain = true;
                }

            } while (checkAgain == true);
        }

        public void LoadScreen()
        {
            Console.Clear();
            Program program = new Program();
            program.Typewrite("Loading", 100);
            program.Typewrite(".....", 600);
            Console.Clear();
        }
    }
}
