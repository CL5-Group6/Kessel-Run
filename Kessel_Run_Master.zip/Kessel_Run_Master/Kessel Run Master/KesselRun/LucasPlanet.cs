﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KesselRun
{
    class LucasPlanet
    {
        bool visitedMarket;
        bool visitedTownSquare;
        bool visitedSaloon;
        bool kalEvent;  //true = special event, false = normal ending
        bool childEvent; //true = special event, false = normal ending
        string planetname = "LUCASION";
        string choice;

        public void runLucasPlanet()
        {
            {   
                Program program = new Program();
                var playSound = new System.Media.SoundPlayer();
                bool checkAgain = true;

                Console.ForegroundColor = ConsoleColor.White;
                program.Typewrite("You are approaching ", 100);
                Console.ForegroundColor = ConsoleColor.Red;
                program.Typewrite($"{planetname}", 100);
                Console.ForegroundColor = ConsoleColor.White;
                Console.ReadLine();

                program.Typewrite("\nTEMPERATURE: ERROR", 100);
                program.Typewrite("\nPOPULATION: 1,205,195,003", 100);
                program.Typewrite("\nOUTSTANDING BOUNTIES", 100);
                program.Typewrite("...", 1000);
                program.Typewrite(" NO CURRENT BOUNTIES", 100);
                Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("\nYOU: Well that is a first.");
                Console.ReadLine();
                Console.Clear(); 

                Console.WriteLine("As you land at the docking bay you are greeted by a friendly worker named KAL.\n");
                Console.ReadLine();
                Console.Clear();
                Console.WriteLine($"KAL: Hi there fella! You seem lost? Well luckily KAL grew up here and knows all about this place!");
                Console.ReadLine();
                Console.WriteLine("KAL: Lets see... The town square is just up ahead.");
                Console.ReadLine();
                Console.WriteLine("KAL: The market is at your first right heading in the same direction as the town square.");
                Console.ReadLine();
                Console.WriteLine("KAL: But after all of that flyin, I bet that you are looking for the saloon.");
                Console.ReadLine();
                Console.WriteLine("KAL: Go completely past the town square and you will find it. A bit of a walk but it is definitely worth it.");
                Console.ReadLine();
                Console.WriteLine("KAL: If you want to go to the SALOON you have to pass through the town square anyways so you might look around when you pass through.");
                Console.ReadLine();

                Console.WriteLine("Thank KAL?.\n");
                Console.WriteLine("1. YES");
                Console.WriteLine("2. NO\n");
                Console.Write("CHOICE: ");

                kalEvent = false;  //true = special event, false = normal ending

                choice = Console.ReadLine();

                if (choice == "1")
                {
                    Console.Clear();
                    Console.WriteLine("KAL: Hey no problem pal! Now go ahead and have a nice stay!");
                    Console.ReadLine();
                    Console.WriteLine("KAL: Oh and don't worry about your ship. I will keep a close eye on her for ya.");
                    Console.ReadLine();
                    Console.Clear();

                    kalEvent = true;
                }
                else if (choice == "2")
                {
                    Console.Clear();
                    Console.WriteLine("KAL: Okay, well see you around I guess.");
                    Console.ReadLine();
                    Console.WriteLine("KAL: H-h-have a nice stay.");
                    Console.ReadLine();
                    Console.Clear();

                    kalEvent = false;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("You say nothing.");
                    Console.ReadLine();
                    Console.WriteLine("Kal laughs nervously...");
                    Console.ReadLine();
                    Console.WriteLine("KAL: Well... guess I'll be seeing you later then.");
                    Console.ReadLine();
                    Console.WriteLine("KAL: But your welcome. I think?\n");
                    Console.ReadLine();
                    Console.Clear();

                    kalEvent = false;
                }

                do
                {
                    Console.WriteLine("Where would you like to go?\n");
                    Console.WriteLine("THE SALOON IS UNAVAILABLE UNTIL REACHING THE TOWN SQUARE.");
                    Console.Write("\n1. MARKET\n2. TOWN SQUARE\n\nCHOICE: ");
                    choice = Console.ReadLine();
                    Console.Clear();


                    if (choice == "1")
                    {
                        checkAgain = false;
                        Console.Clear();
                        market();
                    }
                    else if (choice == "2")
                    {
                        checkAgain = false;
                        Console.Clear();
                        townsquare();
                    }
                    else
                    {
                        Console.WriteLine("YOU: I should probably only go to the MARKET or TOWN SQUARE.\n");
                        checkAgain = true;
                    }

                } while (checkAgain == true);

                Console.ReadLine();
            }                                 
        }
        public void market()
        {
            visitedMarket = true;
            bool checkAgain = true;

            Console.WriteLine("You arrive at the MARKET.\n");
            Console.WriteLine("A broken sign is hanging above a hologram of the store clerk.\n");
            Console.WriteLine("It says 'LAMARR'S LAUNDERED ITEMS'.\n");

            Console.ReadLine();
            Console.Clear();
            Console.WriteLine("HOLOGRAM: ...");
            Console.ReadLine();
            Console.WriteLine("YOU: ...");
            Console.ReadLine();
            Console.WriteLine("HOLOGRAM: ...");
            Console.ReadLine();
            Console.WriteLine("YOU: ...\n");

            do
            {
                Console.WriteLine("Do you GREET the hologram or ask what's for SALE?.\n");
                Console.Write("1. GREET\n2. SALE\n\nCHOICE: ");

                choice = Console.ReadLine();
                Console.Clear();

                if (choice == "1")
                {
                    checkAgain = false;
                    Console.Clear();
                    Console.WriteLine("YOU: Hello there. Are you LAMARR?");
                    Console.ReadLine();

                    Console.WriteLine("HOLOGRAM: Take a wild guess.");
                    Console.ReadLine();

                    Console.WriteLine("His eyes cut up towards the broken sign.");
                    Console.ReadLine();

                    Console.WriteLine("YOU: I thought so. Do you have anything for sale?");
                    Console.ReadLine();

                    Console.WriteLine("LAMARR: Do I look like a store to you bud?\n");
                    Console.ReadLine();

                    Console.WriteLine("What do you say?\n");
                    Console.Write("1. YES\n2. NO\n\nCHOICE: ");

                    choice = Console.ReadLine();
                    Console.Clear();

                    if (choice == "1")
                    {
                        Console.WriteLine("LAMARR: Yeah, no kidding right.");
                        Console.ReadLine();
                        Console.WriteLine("LAMARR: Lets just get to it.\n");
                    }
                    else if (choice == "2")
                    {
                        Console.WriteLine("LAMARR: Well good cause I ain't a store.");
                        Console.ReadLine();
                        Console.WriteLine("LAMARR: There happens to be a collection of items sitting behind my counter that I may or may not sell to you if you were to want something.");
                        Console.ReadLine();
                        Console.WriteLine("LAMARR: Here. Take a look.\n");
                    }
                    else
                    {
                        Console.WriteLine("\nLAMARR continues staring at you for a few moments.");
                        Console.WriteLine("LAMARR: Lets just get on with it.\n");
                    }
                }
                else if (choice == "2")
                {
                    checkAgain = false;
                    Console.Clear();
                    Console.WriteLine("HOLOGRAM: What you just assume that I work here?");
                    Console.ReadLine();
                    Console.WriteLine("His eyes cut up towards the broken sign.");
                    Console.ReadLine();
                    Console.WriteLine("LAMARR: Fair assumption I suppose. Yes I am LAMARR, but I am not a store.");
                    Console.ReadLine();
                    Console.WriteLine("LAMARR: There happens to be a collection of items sitting behind my counter that I may or may not sell to you if you were to want something.");
                    Console.ReadLine();
                    Console.WriteLine("LAMARR: And since you were so inclined, here are some of those items.");
                    Console.ReadLine();
                    Console.Clear();
                }
                else
                {
                    Console.WriteLine("HOLOGRAM: ...\n");
                    checkAgain = true;
                }

            } while (checkAgain == true);

            StoreMenu.RunStoreMenu();

            Console.ForegroundColor = ConsoleColor.White;

            Console.ReadLine();
            Console.WriteLine("You exit the MARKET.");
            Console.ReadLine();
            Console.Clear();

            do
            {
                Console.WriteLine("Where would you like to go?");
                Console.Write("\n1. TOWN SQUARE\n2. SHIP\n3. SALOON\n\nCHOICE: ");
                choice = Console.ReadLine();
                Console.Clear();

                if (choice == "1" && visitedTownSquare == false)
                {
                    checkAgain = false;
                    Console.Clear();
                    townsquare();
                }
                else if (choice == "1" && visitedTownSquare == true)
                {
                    checkAgain = true;
                    Console.Clear();
                    Console.WriteLine("I have already been there. I need to move on.\n");
                }
                else if (choice == "3" && visitedSaloon == true)
                {
                    checkAgain = true;
                    Console.Clear();
                    Console.WriteLine("I have already been there. I need to move on.\n");
                }
                else if (choice == "3" && visitedSaloon == false && visitedTownSquare == true)
                {
                    checkAgain = true;
                    Console.WriteLine("You pass through town square again.\n");
                    Console.ReadLine();
                    Console.Clear();
                    saloon();
                }
                else if (choice == "3" && visitedSaloon == false && visitedTownSquare == false)
                {
                    checkAgain = true;
                    Console.Clear();
                    Console.WriteLine("You remember that you need to pass through town square first.\n");
                }
                else if (choice == "2" && visitedMarket == true && visitedSaloon == true && visitedTownSquare == true)
                {
                    checkAgain = false;
                    Console.Clear();
                    backToShip();
                }
                else if (choice == "2" && visitedMarket == false || visitedSaloon == false || visitedTownSquare == false)
                {
                    checkAgain = true;
                    Console.Clear();
                    Console.WriteLine("I need to keep moving on before I go back to my ship.\n");
                }
                else
                {
                    Console.WriteLine("I need to keep moving on.\n");
                    checkAgain = true;
                }

            } while (checkAgain == true);
        }
        public void townsquare()
        {
            bool checkAgain = true;
            visitedTownSquare = true;

            Console.WriteLine("You arrive at TOWN SQUARE.");
                Console.ReadLine();
                Console.WriteLine("Crowding the streets are citizens of all shapes, sizes, and races.");
                Console.ReadLine();
                Console.WriteLine("While trying to make your way through the busy streets, you notice a group of individuals having a loud confrontation.");
                Console.ReadLine();
                Console.WriteLine("They seem to be gathering around a child, blocking him from moving and starting to become more and more agressive.");
                Console.ReadLine();

            do
            {
                childEvent = false; //if you do not help the child, a secret end level event happens.

                Console.WriteLine("What do you do?.\n");
                Console.Write("1. INVESTIGATE\n2. IGNORE\n\nCHOICE: ");
                choice = Console.ReadLine();
                Console.Clear();

                if (choice == "1")
                {
                    checkAgain = false;
                    Console.WriteLine("You approach the group. The one who appears to be the leader turns around towards you.");
                    Console.ReadLine();

                    Console.WriteLine("THUG 1: Hey buddy you need to take a step back. Trust me, you don't want to get involved.");
                    Console.ReadLine();

                    Console.WriteLine("CHILD: Please help me! I swear I didn't do it!");
                    Console.ReadLine();
                    Console.WriteLine("You can't ignore the situation so you push past the thug blocking your way and approach the child.");
                    Console.ReadLine();

                    Console.WriteLine("The thug stumbles over and turns around to confront you directly but you hastily rush over next to the child before anyone can stop you.");
                    Console.ReadLine();
                    Console.WriteLine("YOU: Wait, wait! Listen I just want to know what happened. What did the child do?");
                    Console.ReadLine();

                    Console.WriteLine("THUG 2: The little punk stole 50 credits right out of my pocket. I turned around and saw it with my own eyes!");
                    Console.ReadLine();
                    Console.WriteLine("CHILD: THAT'S A LIE! Please help me, they are trying to rob me! I didn't take anything from them!");
                    Console.ReadLine();
                    Console.Clear();

                    do
                    {
                        Console.WriteLine("Which side do you take?.\n");
                        Console.Write("1. CHILD\n2. THUGS\n\nCHOICE: ");
                        choice = Console.ReadLine();
                        Console.Clear();

                        if (choice == "1")
                        {
                            checkAgain = false;
                            Console.Clear();
                            Console.WriteLine("YOU: Listen, I believe the child and I think that you all should just calm down and stop trying to take advantage of someone half your size.");
                            Console.ReadLine();
                            Console.WriteLine("THUG 1: I'm only going to say this once, so listen carefully. Leave now, or suffer the same fate as the thief.");
                            Console.ReadLine();

                            do
                            {
                                Console.WriteLine("What do you do?\n");
                                Console.Write("1. STAND DOWN\n2. FIGHT\n\nCHOICE: ");
                                choice = Console.ReadLine();;
                                Console.Clear();

                                if (choice == "1")
                                {
                                    checkAgain = false;
                                    Console.Clear();
                                    childEvent = true;
                                    Console.WriteLine("YOU: Woah, okay lets calm down. I'm not going to make matters worse. Just please don't hurt him. He is just a child.");
                                    Console.ReadLine();
                                    Console.WriteLine("THUG 2: Trust me pal. The boy will be just fine. Now get out of here.");
                                    Console.ReadLine();
                                    Console.WriteLine("CHILD: What... But you said that you believed me?");
                                    Console.ReadLine();
                                    Console.WriteLine("The child begins to cry as you are leaving.");
                                    Console.ReadLine();

                                    Console.WriteLine("Offer 50 credits?\n");
                                Console.Write("1. Yes\n2. No\n\nCHOICE: ");
                                choice = Console.ReadLine();;
                                Console.Clear();

                                    Character character = new Character();

                                    if (choice == "1" && (Character.EvalFunds(-50) == true))
                                    {

                                        Character.AdjustCredits(-50);
                                    Console.WriteLine("In a hushed tone, you whisper to the leader.\n\nYOU: Here is 50 credits. Just don't hurt the boy.");
                                    Console.ReadLine();
                                    Console.WriteLine("THUG 1: Hmmm, I suppose this will do. But you should still leave before I change my mind.");
                                    Console.ReadLine();
                                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                                        Console.WriteLine("50 CREDITS REMOVED");
                                        Console.ForegroundColor = ConsoleColor.White;

                                    Console.ReadLine();
                                    }
                                    else if (choice == "1" && (Character.EvalFunds(-50) == false))
                                    {
                                        Console.WriteLine("I don't have enough credits.");
                                    }
                                    else
                                    {
                                        Console.WriteLine("You hesitate for second, but decide to keep your money.");
                                        Console.ReadLine();
                                        Console.Clear();
                                    }

                                    Console.WriteLine("You continue to walk away from the situation. You turn back around and notice the group staring at you.");
                                    Console.ReadLine();
                                    Console.WriteLine("But you keep walking.");
                                    Console.ReadLine();
                                    Console.Clear();
                                }
                                else if (choice == "2")
                                {
                                    checkAgain = false;
                                    Console.Clear();
                                    childEvent = false;
                                    Console.WriteLine("You pull out your blaster and fire at the leader before he can even unholster his weapon.");
                                    Console.ReadLine();
                                    Console.WriteLine("He tried, but you shot first.");
                                    Console.ReadLine();
                                    Console.WriteLine("The other two thugs fumble for their weapons as you take two well aimed shots, hitting them directly in the head and killing them.");
                                    Console.ReadLine();
                                    Console.WriteLine("CHILD: You killed them!");
                                    Console.ReadLine();
                                    Console.WriteLine("YOU: Yeah, no kidding. It was either them or me. You're welcome by the way.");
                                    Console.ReadLine();
                                    Console.WriteLine("CHILD: Thank you so much!");
                                    Console.ReadLine();
                                    Console.WriteLine("YOU: Don't mention it kid. But next time, be a little bit more careful when taking credits off of someone.");
                                    Console.ReadLine();
                                    Console.WriteLine("The child smiles and takes off running in the opposite direction.");
                                    Console.ReadLine();
                                    Console.Clear();
                                }
                                else
                                {
                                    Console.WriteLine("You need to choose to FIGHT or STAND DOWN.");
                                    Console.ReadLine();
                                    checkAgain = true;
                                }

                            } while (checkAgain == true);
                        }
                        else if (choice == "2")
                        {
                            checkAgain = false;
                            Console.Clear();
                            childEvent = true;
                            Console.WriteLine("YOU: Sorry kid, it ain't nice to take what doesn't belong to you.");
                            Console.ReadLine();
                            Console.WriteLine("YOU: Give them the 50 credits back and they won't hurt you. Right guys?");
                            Console.ReadLine();
                            Console.WriteLine("THUG 1: You heard him kid. Give us what belongs to us and you can go about your day. We won't even report you to the authorities.");
                            Console.ReadLine();
                            Console.WriteLine("You move on from the confrontation.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        else
                        {
                            Console.WriteLine("You need to choose between the CHILD or the THUGS.");
                            Console.ReadLine();
                            checkAgain = true;
                        }

                    } while (checkAgain == true);
                }
                else if (choice == "2")
                {
                    childEvent = true;
                    checkAgain = false;
                    Console.WriteLine("You think to yourself that it's probably best not to get involved. After all, you are an outsider.\n");
                    Console.ReadLine();
                    Console.Clear();
                }
                else
                {
                    Console.WriteLine("YOU: Should I get involved?");
                    Console.ReadLine();
                    Console.Clear();
                    checkAgain = true;
                }

            } while (checkAgain == true);

            Console.WriteLine("The streets are so crowded that you decide to go ahead and move on to somewhere else.");

            do
            {
                Console.WriteLine("\nWhere would you like to go?");
                Console.Write("\n1. MARKET\n2. SALOON\n\nCHOICE: ");
                choice = Console.ReadLine();
                Console.Clear();

                if (choice == "1" && visitedMarket == false)
                {
                    checkAgain = false;
                    Console.Clear();
                    market();
                }
                else if (choice == "1" && visitedMarket == true)
                {
                    checkAgain = true;
                    Console.WriteLine("I have already been there. I need to move on.");
                }
                else if (choice == "2")
                {
                    checkAgain = false;
                    Console.Clear();
                    saloon();
                }
                else
                {
                    Console.WriteLine("I should probably not stick around.");
                    checkAgain = true;
                }

            } while (checkAgain == true);
        }
        public void saloon()
        {
            visitedSaloon = true;
            bool checkAgain = true;

            Console.WriteLine("You arrive at the SALOON.");
            Console.ReadLine();
            Console.WriteLine("You approach the bar and an older gentlman approaches you from the other side.");
            Console.ReadLine();
            Console.WriteLine("BARTENDER: What can I get for ya? Our house special is a 'Booster Blast' for only 5 credits.");
            Console.ReadLine();

            do
            {
                Console.WriteLine("What do you do?\n");
                Console.Write("1. DRINK\n2. NO DRINK\n\nCHOICE:");

                choice = Console.ReadLine();
                choice = choice.ToUpper();
                Console.Clear();

                if (choice == "1")
                {
                    checkAgain = false;
                    //reduce stonks by 5
                    Console.Clear();
                    Console.WriteLine("YOU: Just give me your house special please.");
                    Console.ReadLine();
                    Console.WriteLine("BARTENDER: One Booster Blast coming right up.");
                    Console.ReadLine();
                    Console.WriteLine("The BARTENDER slides the drink your way and you hand him 5 credits.");
                    Console.ReadLine();
                    Console.WriteLine("BARTENDER: So what brings you here?");
                    Console.ReadLine();
                    Console.WriteLine("YOU: I'm just stopping by. It is so busy outside in the town square and I just wanted to relax for a minute.");
                    Console.ReadLine();
                    Console.WriteLine("BARTENDER: Well you certainly picked one of worst places to come and relax. Nothing but loud and rude drunks always trying to start fights.");
                    Console.ReadLine();
                    Console.WriteLine("BARTENDER: We started posting around the clock security to ensure that nobody else gets killed this week.");
                    Console.ReadLine();
                    Console.WriteLine("YOU: It might not be the best place. But it's just where I ended up I guess.");
                    Console.ReadLine();
                    Console.WriteLine("BARTENDER: Well while you are here, let me know if I can get you anything else. The name's HAROLD by the way.");
                    Console.ReadLine();
                    Console.WriteLine("You sit for a while and collect your thoughts before deciding to leave the SALOON.");
                    Console.ReadLine();
                    Console.WriteLine("On your way out you hear a voice from behind you.");
                    Console.ReadLine();
                    Console.WriteLine("HAROLD: Save travels friend!");
                    Console.ReadLine();
                    Console.WriteLine("YOU: *slightly slurring your words* Take care HAROLD.");
                    Console.ReadLine();
                    Console.Clear();
                }
                else if (choice == "2")
                {
                    checkAgain = false;
                    Console.Clear();
                    Console.WriteLine("YOU: Nothing for now. Thanks though.");
                    Console.ReadLine();
                    Console.WriteLine("BARTENDER: So you come into a bar just to sit here and ponder your thoughts? Couldn't you do that from home?");
                    Console.ReadLine();
                    Console.WriteLine("YOU: I'm just stopping by. It is so busy outside in the town square and I just wanted to relax for a minute.");
                    Console.ReadLine();
                    Console.WriteLine("BARTENDER: Well you certainly picked one of worst places to come and relax. Nothing but loud and rude drunks always trying to start fights.");
                    Console.ReadLine();
                    Console.WriteLine("BARTENDER: We started posting around the clock security to ensure that nobody else gets killed this week.");
                    Console.ReadLine();
                    Console.WriteLine("YOU: It might not be the best place. But it's just where I ended up I guess.");
                    Console.ReadLine();
                    Console.WriteLine("BARTENDER: Well while you are here, let me know if I can get you anything. The name's HAROLD by the way.");
                    Console.ReadLine();
                    Console.WriteLine("You sit for a while and collect your thoughts before deciding to leave the SALOON.");
                    Console.ReadLine();
                    Console.WriteLine("On your way out you hear a voice from behind you.");
                    Console.ReadLine();
                    Console.WriteLine("HAROLD: Save travels friend!");
                    Console.ReadLine();
                    Console.WriteLine("YOU: Take care HAROLD.");
                    Console.ReadLine();
                    Console.Clear();
                }
                else
                {
                    Console.WriteLine("BARTENDER: Come again?");
                    Console.ReadLine();
                    Console.Clear();
                    checkAgain = true;
                }

            } while (checkAgain == true);

            visitedSaloon = true;
            Console.WriteLine("You exit the SALOON. The streets are so crowded that you decide to go ahead and move on to somewhere else.");
            Console.ReadLine();

            do
            {
                Console.WriteLine("Where would you like to go?");
                Console.Write("\n1. MARKET\n2. TOWN SQUARE\n3. SHIP\n\nCHOICE: ");
                choice = Console.ReadLine();
                Console.Clear();

                if (choice == "1" && visitedMarket == false)
                {
                    checkAgain = false;
                    Console.Clear();
                    market();
                }
                else if (choice == "1" && visitedMarket == true)
                {
                    checkAgain = true;
                    Console.Clear();
                    Console.WriteLine("I have already been there. I need to move on.\n");
                }
                else if (choice == "2")
                {
                    checkAgain = true;
                    Console.Clear();
                    Console.WriteLine("I have already been there. I need to move on.\n");
                }
                else if (choice == "3" && visitedMarket == false || visitedSaloon == false || visitedTownSquare == false)
                {
                    checkAgain = true;
                    Console.Clear();
                    Console.WriteLine("I should probably look around some more before heading back to my ship.\n");
                }
                else if (choice == "3" && visitedMarket == true && visitedSaloon == true && visitedTownSquare == true)
                {
                    checkAgain = false;
                    Console.Clear();
                    backToShip();
                }
                else
                {
                    Console.WriteLine("I should probably not stick around.\n");
                    checkAgain = true;
                }

            } while (checkAgain == true);


        }
        public void backToShip()
        {
            Console.WriteLine("You make your way back to your ship.");
            Console.ReadLine();
            Console.WriteLine("As you approach you approach the landing dock, you see KAL standing guard by your ship.");
            Console.ReadLine();
            Console.Clear();

            if (kalEvent == true)
            {
                Console.WriteLine("KAL: Hey friend!");
                Console.ReadLine();
                Console.WriteLine("KAL: Somebody left the fuel station running with 70 credits worth of fuel available for pumping.");
                Console.ReadLine();
                Console.WriteLine("KAL: I tried to get his attention but he was in a hurry. So with that being said... I went ahead and topped off the ship for ya! Free of charge!");
                Console.ReadLine();

                //ship fuel needs to be increased to max value;

                Console.WriteLine("YOU: Thanks KAL. I really appreciate you doing that. Take care of yourself.");
                Console.ReadLine();
                Console.WriteLine("KAL: No problem, err... I don't think I ever caught your name?");
                Console.ReadLine();
                Console.WriteLine("YOU: The name is HAN. Thanks again KAL.");
                Console.ReadLine();
                Console.Clear();
            }
            else if (kalEvent == false)
            {
                Console.WriteLine("KAL: Oh, hey there.");
                Console.ReadLine();
                Console.WriteLine("KAL: Hope you enjoyed your stay. Everything should be just as you left it.");
                Console.ReadLine();
            }

            Console.WriteLine($"You get on board your ship and prepare to leave {planetname}.");
            Console.ReadLine();
            Console.Clear();

            if (childEvent == true)
            {
                Console.WriteLine("As the ship begins to start the radio flips on to a local news station.");
                Console.ReadLine();
                Console.WriteLine($"REPORTER: Attention citizens of {planetname}.");
                Console.ReadLine();
                Console.WriteLine($"REPORTER: A group of strangers has been reported by the locals of {planetname} and are known to be extremely hostile.");
                Console.ReadLine();
                Console.WriteLine($"REPORTER: We have reason to believe that the these criminals are part of a larger intergalactic gang of SPACE PIRATES that are looking to establish territory on {planetname}.");
                Console.ReadLine();
                Console.WriteLine($"REPORTER: Since their arrival, 2 local businesses have been robbed and vandalized, as well as reports of a missing child who was last seen in the town square.");
                Console.ReadLine();
                Console.WriteLine("REPORTER: These individuals are known to be extremely violent and will not hesitate to kill, or take innocent citizens for ransom.");
                Console.ReadLine();
                Console.WriteLine("REPORTER: If you see something suspicious, please alert the authorities immediately!");
                Console.ReadLine();
                Console.WriteLine($"The radio signal goes silent as you bring your ship out of the docking bay and make your way off of {planetname}.");
            }
            else if (childEvent == false)
            {
                Console.WriteLine($"You exit the docking bay and make your way off of {planetname}");
            }

            Console.ReadLine();
            RunNextPlanet();
        }  
        public static void RunNextPlanet()
        {
            Program program = new Program();
            ChadPlanet chadplanet = new ChadPlanet();

            program.LoadScreen();
            program.currentPlanet = 3;
            chadplanet.RunPlanet();
            Console.Clear();
        }
    }
}
