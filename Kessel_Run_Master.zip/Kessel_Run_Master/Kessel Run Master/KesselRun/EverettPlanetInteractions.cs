﻿using System;
using System.Text;

namespace KesselRun
{
    class Interactions
    {
        public static void TownSquareConversation()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine(printConversationMenu());
            string userEntry = Console.ReadLine();
            InteractionSwitch(userEntry);
        }
        static void InteractionSwitch(string switchEval)
        {
            Console.ForegroundColor = ConsoleColor.White;
            switch (switchEval)
            {
                case "1":   //SECURITY OFFICIALS
                    Console.WriteLine("You approach two security officials standing off to the side:" +
                        "\nOFFICIAL1: Hey mate, you new around here?" +
                        "\nENTER:" +
                        "\n\"YES\" or \"NO\"");
                    string entry = Console.ReadLine();
                    if (entry.ToUpper() == "YES")
                    {
                        Console.WriteLine("OFFICIAL1: I reckoned you looked a little lost standing there lookin' 'round." +
                            "\nWhat are ya here for? Maybe we can point ya somewheres." +
                            "\nYOU: Where is \'here\'?\nOFFICIAL2: You're in Mos Eisley mate, biggest town on Tatooine." +
                            "\nYOU: Oh, yes, of course... thank you for your help gentlemen!\nYou turn and walk away trying " +
                            "to act calm. Tatooine? Now that's a name you haven't heard in a very long time...");
                        //Console.ReadKey();
                        //Console.Clear();
                        //TownSquareConversation();
                    }
                    else if (entry.ToUpper() == "NO")
                    {
                        Console.WriteLine("OFFICIAL1: No eh? Very well then. What can we help you with?\nYOU: Oh I just " +
                            "came over to ask if it seemed like it was busier here than usual to you? I don't come this" +
                            "\nside of town as much anymore\n\nOFFICIAL2: Nah it's always crowded like this. Although you ain't" +
                            "\nmissing much coming this way, there's enough thugs and bounty hunters on account of the Cantina" +
                            "\ndown the street to make it rather unpleasant sometimes.\n\nYOU: Oh yea?\n\nOFFICIAL1: Yeah it gets" +
                            "rather crazy at the Cantina, people fighting and shooting the place up because everyone there\n" +
                            "is carrying loot on 'em.\n\nOFFICIAL2: Yeah talk to the bartender, he'll tell you all about" +
                            "\nthe gangsters." +
                            "\n\nYOU: Okay, good to know, I'll make sure not to get caught up over there. You gentlemen have" +
                            "\na nice day!" +
                            "\nAs you walk away you make sure to remember to ask the bartender about this.");
                        Console.ReadKey();
                        Console.Clear();
                        TownSquareConversation();
                    }
                    else
                    {
                        Console.WriteLine("The officials look at each other then back to you." +
                            "\nOFFICIAL2: Sorry bud, we don't know your tongue.");
                        //Console.ReadLine();
                        //Console.Clear();
                        //TownSquareConversation();
                    }
                    break;
                case "2":   //SPACE PARTS VENDOR / DARK MATTER STABILIZER the last bool eval statement will be set to true here, must have first bool true to convert dark matter
                    
                    if (PlanetTatooine.greedoBool == true)
                    {
                        Console.WriteLine("You approach the \"SCREAMIN ROOSTER\" and knock on the window shutter. The sound of mechanical tools and" +
                            "\ncracks of arching electricity come to a stop as someone shuffles to the window." +
                            "\n\nSHOP OWNER: Oi! What do ya want?!" +
                            "\n\nYOU: Hey, yeah, you do spacecraft parts and stuff right?" +
                            "\n\nSHOP OWNER: Yeah we do repairs and such." +
                            "\n\nYOU: Do you know what this is or what I can do with it?" +
                            "\nYou produce the cannister you took off of Greedo and show it to the shop owner. His eyes quickly get big." +
                            "\n\nSHOP OWNER: WHAT? How'd you get THAT?! You have any notion what you gots thar?!" +
                            "\n\nYOU: Well no I don't actually, I was..." +
                            "\nThe shop owner slams the window shut. You hear shuffling again as he appears out of an almost invisible" +
                            "\nside door and beckons you inside." +
                            "\nInside, you find yourself in a cluttered workshop full of starnge and wonderous looking tools. Tucked away in a nook" +
                            "\non far wall is a very large machine, but with a simple single contorl panel. In a hushed voice the shop owner" +
                            "\nbegins talking to you..." +
                            "\n\nSHOP OWNER: What you has there is unstabilized Dark Matter! Its the stuff of legends, they say that a cannister that" +
                            "\nsize could produce enough stabilized fuel to power a ship at least 12 parsecs! It's all very theoretical ya see" +
                            "\nand its not a perfect solution. It requires some modifications to the ship normally to accept it, but that's very" +
                            "\nminimal. I could convert this stuff for ya, but it'll cost." +
                            "\n\nYOU: How much are we talking?" +
                            "\n\nSHOP OWNER: Well I'd have to get at  least 500 credits!" +
                            "\n\nYOU: WOAH! 500? are you insane?!" +
                            "\n\nSHOP OWNER: Hey this requires a lot of power, not to mention that it's illegal to run modified fuels in open space!" +
                            "\nIf i did it, you couln't be tellin nobody!" +
                            "\n\nWhat would you like to do?\n 1 : Pay 500 credits\n 2 : Leave");
                        string input = Console.ReadLine();
                        if (input == "1")
                        {
                                
                            if (Character.EvalFunds(-500) == true)
                            {
                                Console.WriteLine(Character.AdjustCredits(-500));
                                Console.Clear();
                                Console.WriteLine("You tranfer him the credits and he takes your cannister to the machine in the back. When he powers it on, all of the" +
                                "\nthe lights flicker and go out. He unscrews the cap to a valve mechanism that you didn't notice before and punches a button on the machine" +
                                "\nopening a small enclosure on the side, where he inserts the canniser and screws it in. He punches the button again, sealing the cannister." +
                                "\nHe fiddles with the menu on the machine's control display before the machine starts a low whine. After a few minutes, it gets quite before starting" +
                                "\nup at a high pitched whine again. Lights near the control display flicker on and off in different orders as the machine beeps and clicks at what seems" +
                                "\nlike random intervals... you step back from the machine and watch...\n\nAfter waiting for what seems like and eternity, the machine quets down and the " +
                                "\nlights all go off. There is a low hissing sound before a green light by the display comes on. A distinct *DING* is emitted from the machine." +
                                "\nThe shop owner walks over and punches the button to open up the enclosure. He unscrews and removes the cannister," +
                                "\nwhich looks and feels exactly as it did before." +
                                "\n\nYOU: So that's it, it's stabilized now?\nSHOP OWNER: Whad ya expect? Magic? The atoms have been realigned, by their valence electrons" +
                                "\ngiving the matter distinction and stability among its quarks." +
                                "\nBy nature it will degrade into being in an unordered state of chaos again, so you best use it in the next few days!" +
                                "\n\nYou leave with a stabilized cannister of Dark Matter tucked into your coat.");
                                PlanetTatooine.darkMatterBool = true;
                            }
                            else if (Character.EvalFunds(-500) == false)
                            {
                            Console.WriteLine("SHOP OWNER: Sorry bub, you don't have enough credits for that.\nYou leave without having your Dark Matter stabilized.");
                            }
                            else if (PlanetTatooine.darkMatterBool == true)
                            {
                                Console.WriteLine("SHOP OWNER: Hurry along and use that Dark Matter mate!\nYou should use your stabilized Dark Matter soon.");
                            }
                        }
                        
                    }
                    else
                    {
                        Console.WriteLine("As you walk the aisles of vendors and pop-up-sops, you notice an interesting shop nested back from the " +
                        "\nbustle and partially obscured by food stands and people eating. Despite the hustle and bustle it stounds out as being " +
                        "\nnot very busy. You approach and knock on a half-open window below a weathered sign that reads \"SCREAMIN ROOSTER\" and " +
                        "\nhas a picture of a rooster riding a rocket out into space as his feathers sly off." +
                        "\nMechanical tools and cracks of arching electricity are audible as you knock on the window shutter..." +
                        "\n\nSHOP OWNER: Oi! What do ya want?!" +
                        "\n\nYOU: Hey I have my own ship and I was just wondering what services you offer..." +
                        "\n\nSHOP OWNER: Just the usual repair stuff is all. If you're looking for them fancy upgraders yull have to go somewheres else!" +
                        "\n\nYOU: That's it? You just do repairs?" +
                        "\n\nSHOP OWNER: We do a few other things as well, but it's all personal side projects is what it is, jus dabblin' in alternative" +
                        "\nfuel sources." +
                        "\nTryna make the galaxy a better place ya know?" +
                        "\n\nYOU: You do alternatve fuels to the regular mix?" +
                        "\nThe shop owner hesitates a moment\nSHOP OWNER: Well... uh... like I said, it's all side projects, just some fun experiments," +
                        "\nwe don sell nun that." +
                        "\nJust a pipe dream is all." +
                        "\n\nYOU: Oh. Okay, sounds good, thank you.\n\nYou leave as the shop owner promptly shuts the window and the noises start back up again." +
                        "\nAlternatitve fuels? Interesting...");
                    }
                    break;
                case "3":   //RANDOM VENDOR 
                    Random rand = new Random();
                    int buy = rand.Next(5, 10);
                    int sell = rand.Next(10, 20);
                    Character.AdjustCredits((sell - buy));
                    Console.WriteLine($"You walk into the market and pick a vendor at random. After haggling for a while you sell him one of your" +
                        $"\nrandom trinkets for {sell}, however, he still convinces you to buy one of his items for {buy}.");
                    break;
                case "4":   //RANDOM LOCAL: GENERATES A RANDOM NUMBER 0-8 AND USES THAT IN A SWITCH TO PICK AN INERACTION 
                    Random rnd = new Random();
                    switch (rnd.Next(0, 9))
                    {

                        case 1:     //STEV-O AND D-LO YELL AT YOU
                            Console.WriteLine("As you search the crowd, a burly man and his bearded companion walk by, the burly " +
                                "guy looks you in\nthe eye as he walks past and without slowing his step yells: \"STONKS!\"" +
                                "To which his companion replies: \"Stonks!?\" " +
                                "\n\nWhat a strange place.");
                            Console.ReadKey();
                            Console.Clear();
                            TownSquareConversation();
                            break;
                        case 2:     //ACCIDENTLY INSULT SOMEONE
                            Console.WriteLine("You approach a nice looking little alien fellow and try to speak with him. He clearly " +
                                "does not know your tongue and you do not know his. You try using gestures to communicate with him" +
                                "but BAM! He punches you in the face mid-gesture!\nWhatever you gestured it was very impolite.");
                            Console.ReadLine();Character.AdjustHealth(-10);// REMOVE HEALTH FOR PUNCH
                            Console.WriteLine($"You loose some health from the puch, which was very powerful and a little slimy..." +
                                $"\n\nYour health is now: {Character.ReturnHealth()}");
                            Console.ReadKey();
                            Console.Clear();
                            TownSquareConversation();
                            break;
                        case 3:     //SMOCK?
                            Console.WriteLine("You see a few men standing aside smoking and decide to strike up a conversation." +
                                "\nAs you approach, one of them offers you whatever it is he is smoking saying \"Smock?\"" +
                                "\nYou try to decline only to be assaulted by a chorus of \"Smock\"s from the group." +
                                "\n\nSmock?...  Smock!...  smock... SMOCK...  Schmock..." +
                                "\n\nYou decide to leave.");
                            Console.ReadKey();
                            Console.Clear();
                            TownSquareConversation();
                            break;
                        case 4:     //THESE AREN'T THE DROIDS YOU'RE LOOKING FOR
                            Console.WriteLine("Making your way into the market, you notice a speeder on the outskirts of the square" +
                                "\nget stopped by a group of security personnel who look absolutely intent on arresting all or some" +
                                "\nof the speeder's occupants. After a few minutes, their demeanor seems entirly changed and they" +
                                "\npeacefully depart. The speeder heads off towards the Cantina. Whoever was in it is very good at pursuasion.");
                            Console.ReadKey();
                            Console.Clear();
                            TownSquareConversation();
                            break;
                        case 5:     //KAL
                            Console.WriteLine("You run into a spaceport worker as he is leaving with food.\n\"S-s-sorry, can't talk" +
                                "right now, I-I'm about to miss my f-flight to my shift the next planet over...\" He hurries along." +
                                "\nYou notice the name patch on his coveralls says \"KAL\" and wonder why he would be an entire planet over...");
                            Console.ReadKey();
                            Console.Clear();
                            TownSquareConversation();
                            break;
                        case 6:     //AN APPOINTMENT
                            Console.WriteLine("You approach a man sitting alone on a bench and attempt to ask him what about business " +
                                "\nin the area, but the moment you ask he glances at you and, while grabbing his things, " +
                                "says\n\"Oh! I'm, uh, late for an appointment...\" and picks up and walks off.");
                            Console.ReadLine();
                            Console.WriteLine("\nWhat a total Chad.\nYou move along to look for someone else.");
                            Console.ReadKey();
                            Console.Clear();
                            TownSquareConversation();
                            break;
                        case 7:     //TODO: FIGHT OR SHOOTING? TAKE HEALTH DAMAGE, RANDOM WEAPON DAMAGES?
                            Console.WriteLine("Moving through the crowd you are noticed by a group of rough guys as you were eavesdroping on their conversation" +
                                ". \nGANGSTER: Hey @#$% what's your problem? You want to come talk to us? Come here" +
                                "\nHe turns and swiftly approaches you and you try to backpedal away..." +
                                "\nYOU: What? no, I was trying to make it to look at the Clothing Vendor's wares!" +
                                "\nHe isn't impressed by your answer and pulls a BlasTech DT-12 from under his coat and takes aim...");
                            Console.WriteLine("\n\nDo you want to:\n1 = Shoot back?\n2 = Try and evade his shots?");
                            //string input = Console.ReadLine();
                            Shootout();//input);
                            void Shootout()
                            {
                                string input = Console.ReadLine();
                                switch (input)
                                {
                                    case "1": //RANDOMLY ASSIGNED HEALTH AND DAMAGE VALUES
                                        Random damage = new Random();
                                        int h = damage.Next(5, 50);
                                        Console.WriteLine($"You pull your blaster and shoot back, doing {damage.Next(35, 75)} damage to your attacker." +
                                            $"\nHe shoots you doing {h} damage to you."); Character.AdjustHealth(-h);
                                        Console.WriteLine($"You both duck away into the crowd reeling from your wounds. Your health is {Character.ReturnHealth()}");
                                        break;
                                    case "2":
                                        Console.WriteLine("You dive behind another food vendor's stall right as he takes a shot." +
                                            "\nThe shot rips a hole in a gas line for the open flame grill. You continue to scurry behind another stall as he contiues approaching." +
                                            "\n\nBOOM!\n\nThe leakng gas eventually ignites as it was traped in the enclosed stall with open flames." +
                                            "\nThe blast tears apart the stall sending shrapnel everywhere and killing your assailant, as well as at least 5 others." +
                                            "\nAs you try to slip away you notice searing pain in you leg and realize you have metal shrapnel in your thigh." +
                                            "\nYou loose some health.");Character.AdjustHealth(-30);
                                        Console.WriteLine($"\nYour health is now: {Character.ReturnHealth()}");
                                        break;
                                    default:
                                        Console.WriteLine("Are you trying to die buddy?! Try again!\nEnter number:\n1 = Shoot back\n2 = Try and evade his shots");
                                        Shootout();
                                        break;
                                }
                                Console.ReadKey();
                                Console.Clear();
                                TownSquareConversation();
                            }
                            break;
                        case 8:     //DARK MATTER INSIGHTS
                            Console.WriteLine("As you pick your way through the crowd, you noticed a closed off group in a hushed conversation." +
                                "\nYou approach to listen...\nALIEN1\"...but it can be extremely tricky, only those with the right skills and tools can pull it off!\"" +
                                "\nALIEN2\"Yes, yes, yes. I absolutely agree, however, you have stated that point many times and that\nhelps not with the matter at hand.\"" +
                                "\nALIEN3\"I heard there was a fellow down here in the Marketplace that could perform some of those stabilizations..." +
                                "\nALIEN4\"YES! He's one of the vendors!\"\nALIEN2\"Quiet down you fool! This isn't a public conversation!\"" +
                                "\nALIEN5\"Alright neow, let's get on wid it. We need dis Dark Mattr stablized an on da double!\"" +
                                "\n\nThe group slowly moves away into the Town Square in the direction of what tlooks like the Screamin Rooster.");
                            break;
                        default:
                            Console.WriteLine("You have decided to change your mind and to not talk with anyone but instead to twidle your thumbs" +
                                "\nand stare into the double suns...");
                            break;

                    }
                    break;
                case "5":   // EAT A RATION: GAIN 10 HEALTH, LOOSE 1 RATION
                    Console.WriteLine(Character.EatRation());
                    break;
                case "0":   //CONTROL PANEL
                    Console.Clear();
                    MainMenu.RunMainMenu();
                    break;
                default:
                    Console.WriteLine("Please enter a valid option.");
                    break;
            }
            Console.ReadKey();
            Console.Clear();
            TownSquareConversation();
        }
        static string printConversationMenu()
        {
            StringBuilder InteractionMenu = new StringBuilder();
              InteractionMenu = InteractionMenu.Append("..........TOWN SQUARE...........");
            InteractionMenu = InteractionMenu.Append("\n|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|");
            InteractionMenu = InteractionMenu.Append("\n|Who would you like to talk to?|");
            InteractionMenu = InteractionMenu.Append("\n|  1 = Security Officials      |");
            InteractionMenu = InteractionMenu.Append("\n|  2 = Ship parts trader       |");
            InteractionMenu = InteractionMenu.Append("\n|  3 = Vendor                  |");
            InteractionMenu = InteractionMenu.Append("\n|  4 = Talk to Random Local    |");
            InteractionMenu = InteractionMenu.Append("\n|  5 = Eat a ration            |");
            InteractionMenu = InteractionMenu.Append("\n|------------------------------|");
            InteractionMenu = InteractionMenu.Append("\n| 0 = Control Panel            |");
            InteractionMenu = InteractionMenu.Append("\n+------------------------------+");
            InteractionMenu = InteractionMenu.Append($"\n    Credits : {Character.ReturnCredits()}");
            InteractionMenu = InteractionMenu.Append($"\n     Health : {Character.ReturnHealth()}");
            InteractionMenu = InteractionMenu.Append($"\n  Ration(s) : {Character.ReturnRations()}");
            InteractionMenu = InteractionMenu.Append("\n+-- -- -- --   --   -- -- -- --+\n");
            return InteractionMenu.ToString();
        }
    }
}
