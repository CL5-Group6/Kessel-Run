﻿using System;
using System.Text;

namespace KesselRun
{
    class MainMenu
    {
        public static void RunMainMenu() //runs the menue allowing repeated cycling through the menu an sending user back to menu to redo choices
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(printMainMenu());
            string userEntry = Console.ReadLine();
            MainMenuSwitch(userEntry);
        }
        static void MainMenuSwitch(string switchEval)
        {
            switch (switchEval)
            {
                case "1":   // TRAVEL TO NEXT PLANET: WILL REQUIRE FUEL FOR FALCON WHICH IS STABILIZED DARK MATTER
                            //AND COMPLETION OF EVEN TO GET DARK MATTER AFTER KILLING GREEDO AND STABILIZING IT AT:
                    if (PlanetTatooine.darkMatterBool == false) //YOU CANNOT TRAVEL TO NEXT PLANET WITHOUT HAVING STABILIZED DARK MATTER
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("You enter the spaceport and instinctivy head to BAY 94... you stop when you" +
                            "\nfind it wondering what has brought you here. You pause, but decide to continue and see what you find." +
                            "\nAs you enter the bay, a hangar chief calls out to you:" +
                            "\n\nHANGAR CHIEF: Hey you! That your ship? It don have any fuel! Jawas siphoned it off the other day." +
                            "\n\nDismayed, you inqure about fuel options." +
                            "\n\nYOU: How can I go about getting some fuel?" +
                            "\n\nHANGAR CHIEF: I'm aweful sorry, but we have nun; strange thing happen, night shif las night, tanker exploded" +
                            "\nall a sudden comin from the planet over!" +
                            "\n\nYOU: How am I supposed to fly out then?!" +
                            "\n\nHANGAR CHIEF: Well, if you can get some stabilized Dark Matter you may be able to use that if your Hyperdrive" +
                            "\ncan back route to your Power Core and run them sublight engines. It'll be a trick if'n it'll work. Not to mention" +
                            "\nthat Dark Matter is a mighty rare resource and commands an even mightier price..." +
                            "\nThe hangar chief trails off into a story about when he used to ship minerals across the Galaxy in the heyday of the republic...");
                        Console.WriteLine("\n\nIt is clear that you will not be able to leave without securing your own fuel. " +
                            "\n\nYou depart, leaving the hanger chief reminiscing about wormhole travel before hyperdrives were common on freighters.");
                    }
                    else if (PlanetTatooine.greedoBool == true && PlanetTatooine.darkMatterBool == true)//YOU CAN TRAVEL TO NEXT PLANET
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Clear();
                        Console.WriteLine("You enter the spaceport and head to BAY 94. As you head into the hangar, the shift" +
                            "\nmanager yells at you:\nMANAGER: Hey Hann! I'm sorry but the Falcon here ain't fueled and you'll have to wait for " +
                            "\nthe next fueling tanker which won't be here until another couple of days." +
                            "\nYou thank him and board anyways, saying that you're just checking some things..." +
                            "\nYou head to the Hyperdrive unit with your stabilized Dark Matter and are able to adapt the Hyperdrive to accept it. " +
                            "\nCautiously you open the Control Computer Panel and reverse route power through the PowerFlux coupling. " +
                            "\nYou hop into the cockpit, and pray beyond hope that she works...\n"); Console.ReadLine();
                        Typewriter.Typewrite("      At first try, the Hyperdrive doesn't power on, you cycle the power sequence a number of times to no avail." +
                            "\n     Then, as if by the Force, you accidentally engage the Hyperdrive first and have the idea" +
                            "\n     to cycle Hyperdrive power while it's engaged... the Hyperdrive turns on and immediately engages," +
                            "\n     beginning a high pitched whine. You restart the engine power sequence and they come to life! You set the coordinates for" +
                            "\n     the nearby planet LUCASION and pull out of the spaceport as Captain Han Solo, leaving a dead Greedo and Tatooine behind you." +
                            "\n\n       Don't we all hate the sand...?\nIt's so coarse.....\n\n", 70);
                        Console.ReadLine();
                        Console.Clear();
                        PlanetTatooine.RunNextPlanet();
                    }

                    break;
                case "2":   //ROUTE TO STORE MENU VIA STOREMENU
                    StoreMenu.RunStoreMenu();
                    break;
                case "3":   //CANTINA Kill Greedo to get unstable dark matter, set first bool statement to true
                    Cantina.CantinaScenario();
                    break;
                case "4":   // TALK IN TOWN SQUARE VIA INTERACTIONS
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("You enter the town square, a bustling, crowed, dusty, and noisy market place." +
                        "\nYou look around for anyone who looks helpful. You see public security officials on patrol" +
                        "\nand a plethora of traders and vendors.");
                    Console.ReadKey();
                    Console.Clear();
                    Interactions.TownSquareConversation();
                    break;
                case "5":   // EAT A RATION: GAIN 10 HEALTH, LOOSE 1 RATION
                    Console.WriteLine(Character.EatRation());
                    break;
                case "0":   //EXITS THE CONSOLE
                    Environment.Exit(0);
                    break;
                default:    //ANYTHING NOT MATCHING AN ABOVE SWITCH HANDLED AND MENU RE-RUN
                    Console.WriteLine("Please enter a valid option.");
                    break;
            }
            Console.WriteLine("Enter to continue...");
            Console.ReadKey();
            Console.Clear();
            RunMainMenu();
        }
        static string printMainMenu()
        {
            StringBuilder mainMenu = new StringBuilder("\n -=-=-=-= KESSEL RUN =-=-=-=-");
            mainMenu = mainMenu.Append("\n +--------------------------+");
            mainMenu = mainMenu.Append("\n | OPERATIONS CONTROL PANEL |");
            mainMenu = mainMenu.Append("\n | ------- -------- ------- |");
            mainMenu = mainMenu.Append("\n |What would you like to do?|");
            mainMenu = mainMenu.Append("\n |  1 = Travel              |");
            mainMenu = mainMenu.Append("\n |  2 = Go to store         |");
            mainMenu = mainMenu.Append("\n |  3 = Visit Cantina       |");
            mainMenu = mainMenu.Append("\n |  4 = Visit Town Square   |");
            mainMenu = mainMenu.Append("\n |  5 = Eat a ration        |");
            mainMenu = mainMenu.Append("\n | ------- -------- ------- |");
            mainMenu = mainMenu.Append("\n |  0 to leave game.        |");
            mainMenu = mainMenu.Append("\n +--------------------------+");
            mainMenu = mainMenu.Append($"\n     Credits : {Character.ReturnCredits()}");
            mainMenu = mainMenu.Append($"\n      Health : {Character.ReturnHealth()}");
            mainMenu = mainMenu.Append($"\n   Ration(s) : {Character.ReturnRations()}");
            mainMenu = mainMenu.Append("\n +--------------------------+\n");
            return mainMenu.ToString();
        }
    }
}
