﻿using System;

namespace KesselRun
{
    class Character
    {
        static int credits = 200;
        static int health = 100;
        static int Rations = 0;
        public static string AdjustCredits(int x)
        {
            if (EvalFunds(x) == true)
            {
                credits += x;
                return $"You now have {credits} credits.";
            }
            else
            {
                return "You don't have enough credits";
            }
        }
        public static void AdjustHealth(int x)
        {
            health += x;
            if(health > 100)
            {
                health = 100;
            }
            else if (health <= 0)
            {
                Console.Clear();
                Console.WriteLine("You lost too much health and have died!");Console.ReadLine();Console.Clear();
                Console.WriteLine("YOU HAVE FAILED THIS PLANET");Console.ReadLine();Console.Clear();
                credits = 200; health = 100; Rations = 0;
                PlanetTatooine.RunPlanetTatooine();
            }
        }
        public static int ReturnCredits()
        {
            return credits;
        }
        public static string ReturnHealth()
        {
            string healthMeter = $"[{health.ToString()} / 100]";
            return healthMeter;
        }
        public static void AdjustRations(int x)
        {
            Rations += x;
            
            if (Rations < 0)
            {
                Rations = 0;
                Console.WriteLine("You don't have any rations left.");
            }
            else if (Rations >= 0)
            {
                Rations += 0;
            }

        }
        public static int ReturnRations()
        {
            return Rations;
        }
        public static string EatRation()
        {
            if(Rations > 0)
            { 
                AdjustRations(-1);
                AdjustHealth(20);
                return "You eat a ration.";
            }
            else
            {
                return "You don't have any rations left";
            }
            
            
        }
        public static bool EvalFunds(int cost)
        {
            int eval = credits;
            if ((eval += cost) >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
