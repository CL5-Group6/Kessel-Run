﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KesselRun
{
    class Hoth
    {
        public void RunHoth()
        {
            PlanetTitle();
        }

        public static void PlanetTitle()
        {
            Console.WriteLine("Welcome to the Planet Hoth...");
            Console.WriteLine("Press enter to begin");
            Console.ReadLine();
            Console.Clear();
            FirstPart();
        }

        public static void FirstPart()
        {
            Console.WriteLine("You tried to avoid it, \n" +
           "but the Millenium Falcon was short on fuel after that last space battle with those TIE Fighters... \n" +
           "You had no choice but to land on the planet Hoth...");
            Console.ReadLine();

            Console.WriteLine("You remember this place well... it was once the home of the Rebel Base, before the Empire took it over.\n" +
                "You were once here with Leia and Luke, and it brings back some distraught memories...");
            Console.ReadLine();
            Console.WriteLine("Han: Well Chewie, I didn't think we'd ever be here again, I knew you missed it.\n" +
                "Chewbacca: RRWWWGG.\n" +
                "Han: Yea I hear you pal. I don't like it very much either...");
            Console.ReadLine();
            Console.Clear();

            playerFirstChoice:
                Console.Write("You now have a few options: \n" +
                "1. Traverse the icy plains to the next town. \n" +
                "2. Sleep in the Millenium Falcon to get some well needed rest. \n" +
                "3. Exit the game. \n" +
                "What is your choice?.. : ");
            string playerFirstChoice = Console.ReadLine();
            Console.Clear();

            switch (playerFirstChoice)
            {
                case "1":
                case "traverse":
                    {
                        Console.WriteLine("You begin traversing the icy plain. Some time passes by... \n" +
                    "Han: It feels like we've been walking for 12 parsecs huh Chewie? \n" +
                    "Chewbacca: GGWWWRGHH. ");
                        Console.ReadLine();
                        SecondPart();
                        break;
                    }

                case "2":
                case "sleep":
                    {
                        Console.WriteLine("Han: Alright Chewie, I'm going to bed and we'll think about our next move tomorrow. How about it? \n" +
                    "Chewbacca: GGWWWRGHH.\n" +
                    "Han: Ahhh shut up Chewie you only have to sleep for an hour! I have to sleep for at least 8!\n" +
                    "Chewbacca: GGWWWRGHH.\n" +
                    "You and Chewie get some rest. You both start your trek across the icy tundra to the town the next morning.");
                        Console.ReadLine();
                        SecondPart();
                        break;
                    }

                case "3":
                case "exit":
                    {
                        Console.WriteLine("WAGRRRRWWGAHHHHWWWRRGGAWWWWWWRR!\n" +
                    "Chewie is upset you're leaving the game. But this is your prerogative.");
                        Console.ReadLine();
                        Environment.Exit(0);
                        break;
                    }

                default:
                    {
                        Console.WriteLine("WAGRRRRWWGAHHHHWWWRRGGAWWWWWWRR!\n" +
                   "Chewie is upset you chose an invalid option. Please choose again.\n");
                        goto playerFirstChoice;
                        //Console.ReadLine();
                        break;
                    }
            }
        }

        public static void SecondPart()
        {
        playerSecondChoice:
            Console.WriteLine("Han comes across a tauntaun. You have been traveling for a while and are really cold and hungry, \n" +
                "but you are far, far away, from the nearest town, \n" +
                "far enough that you consider three things...\n" +
            "1. You can shoot the tauntaun with your blaster and eat it's remains. \n" +
            "2. You can shoot it with your blaster and sleep inside of it, like Luke once did. \n" +
            "3. You can befriend it and ride him into town. You'll get to town faster. \n" +
            "4. Exit the game. \n" +
                "What is your choice?.. : ");
            string playerSecondChoice = Console.ReadLine();
            Console.Clear();

            if (playerSecondChoice == "1")
            {
                Console.WriteLine("You shoot the tauntaun a few times with your blaster and it screams in agony \n" +
                    "The tauntaun falls on the ground and it thumps. You cut it open with your space knife and take out what you want to eat. \n" +
                    "You heat up the remains over your special space heater and eat the tauntaun meat medium rare. Yum... Chewy eats it rare...");
                Console.ReadLine();
                Console.Clear();
                ThirdPart();
            }

            else if (playerSecondChoice == "2")
            {
                Console.WriteLine("You shoot the tauntaun with your blaster and it starts to run at you! \n" +
                    "you panic and instinctively stab it with your space knife. You defeat the tauntaun. You wonder why Chewie doesn't help you...\n" +
                    "Han: You useless furball! Where were you?! \n" +
                    "Chewbacca: RRRAARRWHHGWWR");
                Console.ReadLine();
                Console.Clear();
                ThirdPart();
            }

            else if (playerSecondChoice == "3")
            {
                Console.WriteLine("Chewie decides to speak to the tauntaun in some language you've never heard him speak.\n" +
                    "But then again, it always sounds like gibberish to you. \n " +
                    "After ten seconds the tauntaun slowly walks up to you and grazes it's head on your shoulder. \n " +
                    "Han: Chewie, I guess you are useful sometimes. \n " +
                    "Chewbacca: GGWWWRGHH. \n" +
                    "You both ride the friendly tauntaun into town... ");
                Console.ReadLine();
                Console.Clear();
                ThirdPart();
            }

            else if (playerSecondChoice == "4")
            {
                Console.WriteLine("WAGRRRRWWGAHHHHWWWRRGGAWWWWWWRR!\n" +
                   "Chewie is upset you're leaving the game. But this is your prerogative.");
                Console.ReadLine();
                Environment.Exit(0);
            }

            else
            {
                Console.WriteLine("WAGRRRRWWGAHHHHWWWRRGGAWWWWWWRR!\n" +
                "Chewie is upset you chose an invalid option. Please choose again.");
                Console.ReadLine();
                Console.Clear();
                goto playerSecondChoice;
                
            }

        }

        public static void ThirdPart()
        {
            
            Console.WriteLine("Han and Chewie finally arrive at the town of Davidson. \n" +
                "There you see a tavern named Big E's Tavern. You walk by it and can't help but notice the space pirates lurking inside.\n" +
                "It's a dingy place and doesn't appear too welcoming or appetizing for that matter.\n" +
                "The menu mostly consists of rare tauntaun and wampa on a stick. Maybe Chewie will enjoy dining here.");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You also notice a store named LaMarr's Laundered Items. You've been to many on your journey.\n " +
                "This particular location looks dirtier and slimier than the ones on the other planets. You mention to Chewie...\n" +
                "Han: Remember the last time we went to Lamarr's Chewie? That guy was such a slimeball.\n" +
                "Chewbacca: WWWRRRRRRGWWWRRRR. ");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You come across a stranger who keeps talking in the third person. He talks fast \n" +
                "and is a bit difficult to understand. It sounds like his name is Chaddars.\n" +
                "Chaddars appears to be offering words of advice and general information about the icy planet of Hoth.");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You finally come across a gentleman named Stevenidium 5XXTentacion and he says he owns the local inn. \n" +
                "You wonder if the planet Stevenidium 5XXTentacion is named after him.\n" +
                "Han: Wait, you're claiming that a planet is named after you? I think you're lying to me pal. \n" +
                "Stevenedium: Daaahhh, quit calling me a liar. I work out and you making me act up! \n" +
                "Han: Alright sorry. Me and Chewie are looking for a place to crash. Got anything available. Hopefullly with seperate beds.\n" +
                "Chewie: RRWWWGG. \n" +
                "Han: I don't want to share a bed with you Chewie. You stink!\n" +
                "Stevenedium: Daaahhh yea I think i have something available. It'll cost ya some stonks. I love stonks.");
            Console.ReadLine();
            Console.Clear();

        playerThirdChoice:
            Console.WriteLine("You can choose to do a few things...\n" +
                "1. Enter Big E's Tavern to drink and eat\n" +
                "2. Enter LaMarr's Laundered Items to trade\n" +
                "3. Talk to Chaddars\n" +
                "4. Go back to your ship after resting at the local Space Inn.\n" +
                "5. Exit the game\n" +
                "What is your choice?.. : ");
            string playerThirdChoice = Console.ReadLine();
            Console.Clear();

            //Random rnd = new Random();
            //string[] ChadOptions = {"This here is the coldest planet this side of the Outer Rim!",
            //"I once killed a Wampa with my bare hands!",
            //"Yea! I'm running late for an appointment! Goodbye!",
            //"Hey! I'm running low on Stonks. I'll give you all the stonks I have for one of your JUUL Pods!",
            //"Yea! People call me Chaddars, but my real name is Chad..."};
            //int randomNumber = rnd.Next(0, 5);
            //string secText = ChadOptions[randomNumber];

            //Console.WriteLine(secText);
            //Console.ReadLine();

            if (playerThirdChoice == "1")
            {
                Console.WriteLine("You walk into the tavern and notice space pirates sitting in one corner\n" +
                    "and locals in the other. You and Chewie simply want to grab a bite to eat and maybe a drink.\n" +
                    "Perhaps a beer!");
                Console.ReadLine();
                GameOver();
            }

            else if (playerThirdChoice == "2")
            {
                Console.WriteLine("You enter LaMarr's Laundered Items and take a look around. There's a multitude of items on the shelves\n" +
                    "Including blasters, ship parts, and what appear to be Stonks. It looks exactly like LaMarr's everywhere else.\n " +
                    "You hear a noise and you quickly turn around. It's LaMarr! He strikes a convesation with you but Chewie freaks out." +
                    "Chewbacca: WAGRRRRWWGAHHHHWWWRRGGAWWWWWWRR.\n" +
                    "LaMarr: Whoa hey easy there pal! It's just me, LaMarr! I just came to say hey! \n" +
                    "Han: Yea easy pal it's alright.\n" +
                    "Chewbacca: RRWWWGG.\n" +
                    "Han: What brings you to these parts LaMarr?\n" +
                    "LaMarr: Hey man you know I should be asking you the same question. You're a long way from home.\n" +
                    "Han: You can answer my question at any time.\n" +
                    "LaMarr: Ah ha my man. I sure did miss you Solo.\n" +
                    "Well look I came out here cuz I heard people sometimes have trouble getting supplies here.\n" +
                    "I'm just here to help travelers that get stranded on this worthless planet.\n" +
                    "Han: You're here out of the goodness of your heart? I doubt it.\n" +
                    "LaMarr: Hey Solo I'm here to help I swear. I'll prove it to ya. I got some good deals for you.\n" +
                    "Check it out... I got it all! Blaster pods! Gravity Blankets! Dark matter! Speeder...\n" +
                    "Han: Hold on. You have Dark Matter? How much?\n" +
                    "LaMarr: Plenty of it my friend. For you Solo, i'll give you a deal on it. The first batch is free.\n" +
                    "Han: Really? What's the catch? \n" +
                    "LaMarr: Well you've given me a lot of business over the years. I think it's time to return the favor is all.\n" +
                    "Han: Why thank you pal. You're not so bad after all I suppose.\n" +
                    "Chewbacca: RAWRGWAWGGR.\n" +
                    "LaMarr: Anything for you my friends. \n" +
                    "Han: How'd you even get Dark Matter?\n" +
                    "LaMarr: Well I had to give away some Stonks to get em... Ahhh I'd rather not talk about it.");
                Console.ReadLine();
                GameOver();
            }

            else if (playerThirdChoice == "3")
            {
                Hoth.ChadOptions();
                //Console.WriteLine();
                Console.ReadLine();
                GameOver();
            }

            else if (playerThirdChoice == "4")
            {
                Console.WriteLine("You decide to sleep at the local inn to recover\n" +
                    "Unfortunately, Stevenedium only had a queen cot available, so you and Chewy weren't too comfortable\n"  +
                    "Han: Stop touching me Chewie!\n" +
                    "Chewbacca: AAARARRRGWWWH.\n");
                Console.ReadLine();
                GameOver();
            }

            else  if (playerThirdChoice == "5")
            {
                Console.WriteLine("WAGRRRRWWGAHHHHWWWRRGGAWWWWWWRR!\n" +
                "Chewie is upset you're leaving the game. But this is your prerogative.");
                Console.ReadLine();
                Environment.Exit(0);
            }

            else
            {
                Console.WriteLine("WAGRRRRWWGAHHHHWWWRRGGAWWWWWWRR!\n" +
                "Chewie is upset you chose an invalid option. Please choose again.\n");
                goto playerThirdChoice;
            }

        }

        public static void GameOver()
        {
            Console.Clear();
            Console.WriteLine("The next morning...\n" +
                "Han: Well Chewie I think i'm done with this place. We have everything we need\n" +
                "Chewie: RRWWWGG\n" +
                "Han: Alright pal let's head on back.");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("You finally arrive back at the Millenium Falcon and start her up\n " +
                "not knowing where your next adventure will take you...");
            Console.Clear();
            YouWin();
        }

        public static void YouWin()
        {
            Console.WriteLine("It looks like you've made it to Deep Space. From here, the choices are limitless. \n" +
                "You don't know where the galaxy will take you, but it doesn't matter, so long as Chewie is by your side.");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("Chewbacca: WWWRRRRRRGWWWRRRR!");
            Console.ReadLine();
            Console.Clear();

            Console.WriteLine("Thank you for playing.");
            Console.ReadLine();

            Program program = new Program();
            program.EndCredits();
        }
        public static void ChadOptions()
        {
            Random rnd = new Random();
            string[] ChadOptions = {"This here is the coldest planet this side of the Outer Rim!",
            "I once killed a Wampa with my bare hands!",
            "Yea! I'm running late for an appointment! Goodbye!",
            "Hey! I'm running low on Stonks. I'll give you all the stonks I have for one of your JUUL Pods!",
            "Yea! People call me Chaddars, but my real name is Chad..."};
            int randomNumber = rnd.Next(0, 5);
            string secText = ChadOptions[randomNumber];

            Console.WriteLine(secText);
            Console.ReadLine();
        }
    }
}
