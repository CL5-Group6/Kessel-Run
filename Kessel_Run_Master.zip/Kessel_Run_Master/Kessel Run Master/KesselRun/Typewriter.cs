﻿using System;
//using System.Windows.Forms;

namespace KesselRun
{
    class Typewriter
    {
        public static void Typewrite(string message, int lagtime)
        {
            for (int i = 0; i < message.Length; i++)
            {
                //Cursor.Hide();
                Console.Write(message[i]);
                System.Threading.Thread.Sleep(lagtime);
                //Cursor.Show();
            }
        }
    }
}
