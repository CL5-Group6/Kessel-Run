﻿using System;
using System.Text;

namespace KesselRun
{
    class StoreMenu
    {
        public static void RunStoreMenu() //runs the menu allowing repeated cycling through the menu an sending user back to menu to redo choices
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(PrintStoreMenu());
            string userEntry = Console.ReadLine();
            StoreSwitch(userEntry);
        }
        static void StoreSwitch(string switchEval)//pass in a arg here for switch case 
        {
            Program program = new Program();
            
            switch (switchEval)
            {
                case "1":   // PURCHASE RATIONS
                    Console.WriteLine(PurchaseRation(-10));
                    Console.ReadKey();
                    Console.Clear();
                    RunStoreMenu();
                    break;
                case "2":   // STONK 10
                    Console.WriteLine(PurchaseStonk(-10, 10));
                    Console.ReadKey();
                    Console.Clear();
                    RunStoreMenu();
                    break;
                case "3":   // STONK 20
                    Console.WriteLine(PurchaseStonk(-20, 20));
                    Console.ReadKey();
                    Console.Clear();
                    RunStoreMenu();
                    break;
                case "4":   // STONK 30
                    Console.WriteLine(PurchaseStonk(-30, 30));
                    Console.ReadKey();
                    Console.Clear();
                    RunStoreMenu();
                    break;
                case "5":   // STONK 40
                    Console.WriteLine(PurchaseStonk(-40, 40));
                    Console.ReadKey();
                    Console.Clear();
                    RunStoreMenu();
                    break;
                case "6":   // INFO
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine(" + Space Rations are an excellent source of highly processed chemicals and calories and" +
                        "\n   they're great for your health! Or so they say... They cost 5 credits and will heal you by 20 health. (+20)" +
                        "\n\n + Stonks are a form of currency, but more technically they are a fluctuating commodity that are often bought and " +
                        "\n   sold on the Stonk Market. Your return may be an increase or decrease of 0% to 150% of the share price." +
                        "\n   For example, a 10 credit Stonk will return within a range of 0 - (1.5 * 10) credits... Essentially you're gambling." +
                        "\n   There are 10, 20, 30, & 40 credit options which indicate share price and potential return range.");
                    Console.ReadKey();
                    Console.Clear();
                    RunStoreMenu();
                    break;
                case "0":
                    switch (program.currentPlanet)
                    {
                        case 1:
                            {
                                Console.Clear();
                                MainMenu.RunMainMenu();
                                break;
                            }
                        case 2:
                            {
                                Console.Clear();
                                break;
                            }
                        case 3:
                            {
                                Console.Clear();
                                break;
                            }
                        //case 4:
                        //    {
                        //        Console.Clear();
                        //        MainMenu.RunMainMenu(); TODO: IS NECESSARY TO ADD REF?
                        //        break;
                        //    }
                        case 5:
                            {
                                Console.Clear();
                                //MainMenu.RunMainMenu(); TODO: IS NECESSARY TO ADD REF?
                                break;
                            }
                    }
                    Console.Clear();
                    break;
                default:
                    Console.WriteLine("LAMARR:\n\"Whad ya want eh?!\"");
                    Console.ReadKey();
                    Console.Clear();
                    RunStoreMenu();
                    break;
            }
        }
        static string PrintStoreMenu()
        {
            StringBuilder storeMenu = new StringBuilder("\n");
            storeMenu = storeMenu.Append("\n  ~ LAMARR'S LAUNDERED ITEMS ~");
            storeMenu = storeMenu.Append("\n  *************************** ");
            storeMenu = storeMenu.Append("\n [      | Make-A-Choice |    ]");
            storeMenu = storeMenu.Append("\n [  AVAILABLE  FOR  PURCHASE ]");
            storeMenu = storeMenu.Append("\n [ 1 = Purchase Ration  (10) ]");
            storeMenu = storeMenu.Append("\n [ 2 = Purchase Stonk   (10) ]");
            storeMenu = storeMenu.Append("\n [ 3 = Purchase Stonk   (20) ]");
            storeMenu = storeMenu.Append("\n [ 4 = Purchase Stonk   (30) ]");
            storeMenu = storeMenu.Append("\n [ 5 = Purchase Stonk   (40) ]");
            storeMenu = storeMenu.Append("\n [ 6 = INFO                  ]");
            storeMenu = storeMenu.Append("\n [---------------------------]");
            storeMenu = storeMenu.Append("\n [ 0 = exit the store.       ]");
            storeMenu = storeMenu.Append("\n [---------------------------]");
            storeMenu = storeMenu.Append($"\n     Credits : {Character.ReturnCredits()}");
            storeMenu = storeMenu.Append($"\n      Health : {Character.ReturnHealth()}");
            storeMenu = storeMenu.Append($"\n   Ration(s) : {Character.ReturnRations()}");
            storeMenu = storeMenu.Append("\n [---------------------------]\n");

            return storeMenu.ToString();
        }
        static int Stonks(int input)
        {
            double d = (input * 1.5);
            int limit = Convert.ToInt16(d);
            Random rnd = new Random();
            int amount = rnd.Next(0, limit);
            Character.AdjustCredits(amount);
            return amount;
        }
        static string PurchaseRation(int cost)
        {
            string output;
            if (Character.EvalFunds(cost) == true)
            {
                Character.AdjustRations(1);
                output = $"{Character.AdjustCredits(cost)}\nRation purchased. You have {Character.ReturnRations()} rations.";
            }
            else
            {
                output = $"{Character.AdjustCredits(cost)}";
            }
            return output;
        }
        static string PurchaseStonk(int cost, int stonk)
        {
            string output;
            if (Character.EvalFunds(cost) == true)
            {
                Character.AdjustCredits(cost);
                output = $"Your Stonk returned {Stonks(stonk)} credits.\nYou now have {Character.ReturnCredits()} credits.";
            }
            else
            {
                output = $"{Character.AdjustCredits(cost)}";
            }
            return output;
        }
    }
}
