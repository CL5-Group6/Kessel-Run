﻿using System;
//using System.Windows.Forms;

namespace KesselRun
{
    class Intro
    {
        public static void RunIntro()
        {
            Console.ForegroundColor = ConsoleColor.White;
            //Cursor.Hide();
            Typewriter.Typewrite("Roy Batty turns to look at you, the rain is pouring down on him as he" +
                    "\nsits collapsed on his knees, dying, after having saved your life...", 60);
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Typewriter.Typewrite("\n\n\"I've seen things you people wouldn't believe. " +
                    "\nAttack ships on fire off the shoulder of Orion. " +
                    "\nI watched C-beams glitter in the dark near the Tannhäuser Gate. " +
                    "\nAll those moments will be lost in time, like tears in rain...\"", 90);
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
            Console.Clear();
            Console.Write("SMACK!\n\nAll of a sudden a blast of hot sand born upon dry winds hits you in the face");
            Typewriter.Typewrite("...", 100);
            Typewriter.Typewrite("\n\nYou awake from your dream to an unfamiliar desert place,\nyet you feel you have known it all your life...", 70);
            Console.ReadKey();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Typewriter.Typewrite("Location: Unknown\nDate: Unknown\nTime: Unkown\nYourself: ", 70);
            Typewriter.Typewrite("Unknown", 200);
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
            Typewriter.Typewrite("\n\nYou drag yourself to your feet, up and out of the sand. You are not sure how you got" +
                "\nhere, where \'here\' is, or who you are, but your entire body hurts. You turn around to see a town about" +
                "\na mile away over a sand dune. From where you stand, no one would have seen you laying in the sand." +
                "\nAs you make your way to the town, your hands instinctively find their way to your holstered blaster." +
                "\nYou do not remember it, so you pull it out and look at it. Stamped on the side is \"BlasTech DL - 44\"." +
                "\nYou re-holster it, knowing that it may come in handy...", 60);
            Console.ReadLine();
            Console.Clear();
            Typewriter.Typewrite("You arrive on the outskirts of town and read a directory titled: \"Mos Eisley\"." +
                "\nYou note the location of a few important places and dissapear with the crowd.", 60);
            //Cursor.Show();
            Console.ReadLine();
            Console.Clear();
        }
    }
}
