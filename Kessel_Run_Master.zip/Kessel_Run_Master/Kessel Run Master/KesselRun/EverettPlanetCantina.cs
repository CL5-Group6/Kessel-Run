﻿using System;
using System.Text;

namespace KesselRun
{
    class Cantina
    {
        static bool conversate = false;
        static bool getstuff = false;
        public static void CantinaScenario()
        {
            
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine(printCantinaMenu());
            string userEntry = Console.ReadLine();
            CantinaSwitch(userEntry);
        }
        static void CantinaSwitch(string eval)
        {
            Console.ForegroundColor = ConsoleColor.White;
            
            switch (eval)
            {
                case "1":   // TALK TO BARTENDER JONES SR -- JUNIOR
                    Cantina.conversate = true;
                    if (PlanetTatooine.greedoBool == false)
                    {
                        Console.WriteLine("As you step in you hear a commanding voice from across the room and you know that it is" +
                        "\ndirected towards you. \"JUNIOR! Is that you?!\" The voice is the bartender's, yet it is strangely familiar..." +
                        "\nYou walk over to the bartender who immediately begins again...\nBARTENDER: Junior, You shouldn't have come here!" +
                        "\nYOU: Listen Dad, I know what I'm doing... dad?\nJONES SR: Listen son, there's this fellow Greedo who's looking for you; you better leave before he get you." +
                        "\nYOU: Me? What does he want from me?\nJONES SR:You owe him money and he'll get it from you any way he can! You ought to have tidied this up!" +
                        "\nYOU: Oh me tidy things up? Don't you start with me dad, remember when...");
                    }
                    else if (PlanetTatooine.greedoBool == true)
                    {
                        Console.WriteLine("JONES SR: Son, look what you've gone and done, you need to leave before someone else comes for you!" +
                            "\nYOU: Hey do you know what this is?\nYou show him the cannister that you took from Greedo." +
                            "\nJONES SR: I haven't seen anything like this before, but judging by the markings here near the bottom," +
                            "\nit has to do with a propulsion system of some sort." +
                            "\nThere's been a lot of funny things going on with space travel recently, this may be tied to it...");
                    }
                    
                    break;
                case "2":   // START A FIGHT
                    Random damage = new Random();
                    Random money = new Random();
                    Console.WriteLine("You look around the bar and pick an individual at random...");
                    Random rnd = new Random();
                    switch (rnd.Next(1,4))
                    {
                        case 1:
                            int x = damage.Next(0, 10);
                            int a = money.Next(10, 30);
                            Character.AdjustHealth(-x);
                            Console.WriteLine($"You jack up a thug but loose {x} health in the fight.\nYou search him for credits and find {a} credits");
                            Character.AdjustCredits(a);
                            break;
                        case 2:
                            int y = damage.Next(0, 40);
                            int b = money.Next(15, 60);
                            Character.AdjustHealth(-y);
                            Console.WriteLine($"You cap a gangster but loose {y} health in the fight.\nYou search him for credits and find {b} credits");
                            Character.AdjustCredits(b);
                            break;
                        case 3:
                            int z = damage.Next(0, 50);
                            int c = money.Next(20, 70);
                            Character.AdjustHealth(-z);
                            Console.WriteLine($"You thrash an alien but loose {z} health in the fight.\nYou search him for credits and find {c} credits");
                            Character.AdjustCredits(c);
                            break;
                    }
                    break;
                case "3":   // LOOK AROUND
                    if (conversate == false && getstuff == false)
                    {
                        Console.WriteLine("You walk around the bar to get a feel for the place..." +
                            "\nIt's clearly a rough spot, gangsters, thugs, bounty hunters, all fill the booths and tables." +
                            "\nYou catch an aweful lot of angry looks, but everyone minds their own business.");
                    }
                    else if (conversate == true && getstuff == false)
                    {
                        Console.WriteLine("You sit down at a table in view of the door to wait and think... and wouldn't you know it" +
                            "not a few minutes later\nin walks an alien who matches Greedo's description. He spots you and immediately heads your way." +
                            "GREEDO: Why hello Han.\nYOU: Greedo, good to see you're still in business.\nGREEDO: That's why I'm here actually.\nGreedo draws his blaster." +
                            "\nYOU: Oh? You want to do business with me?\nGREEDO: No Han, you are my business. You know how much money you owe. I've been waiting a long time for this..." +
                            "\nYOU: Yes I'll bet you have...\n\nDo you want to: \n1 : Shoot Greedo\n2 :Continue negotiating");
                        if (Console.ReadLine() == "1")
                        {
                            Console.WriteLine("The entire time Greedo has been talking you've had your blaster pointed at him under the table and you're not" +
                                "\ntaking anymore chances with this gangster who seems intent on bagging you, so you shoot first and grease him...\n\n" +
                                "Everyone in the Cantina looks over at you, but no one moves. An older man in a robe accompanied by a younger in matching attire and two driods" +
                                "\nlook your way.\nYou decide to search Greedo's body to see if he has anything useful and you find a serious looking cannister marked" +
                                "\n\"M, Dark : Extremely Unstable!\".");
                            PlanetTatooine.greedoBool = true;
                            getstuff = true;
                        }
                        else
                        {
                            Console.WriteLine("He shoots you.\nGreedo shoots first.");
                            Console.ReadLine();
                            Character.AdjustHealth(-100);
                        }
                    }
                    else if (conversate == true && getstuff == true)
                    {
                        Console.WriteLine("As you walk around, you notice everyone intently watches your actions." +
                            "\nYou should probably leave.");
                    }
                    break;
                case "4":   // EAT A RATION: GAIN 10 HEALTH, LOOSE 1 RATION
                    Console.WriteLine(Character.EatRation());
                    break;
                case "0":
                    Console.Clear();
                    MainMenu.RunMainMenu();
                    break;
                default:
                    Console.WriteLine("People stare at you as you stand awkwardly in the doorway...");
                    break;
            }
            Console.ReadKey();
            Console.Clear();
            CantinaScenario();
        }
        static string printCantinaMenu()
        {
            StringBuilder CantinaMenu = new StringBuilder();
              CantinaMenu = CantinaMenu.Append("\n /\\/\\/\\/\\/\\/ CANTINA \\/\\/\\/\\/\\/\\");
            CantinaMenu = CantinaMenu.Append("\n /~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\\");
            CantinaMenu = CantinaMenu.Append("\n \\            Actions           /");
            CantinaMenu = CantinaMenu.Append("\n /    1 = Talk to Bartender     \\");
            CantinaMenu = CantinaMenu.Append("\n \\    2 = Start a fight         /");
            CantinaMenu = CantinaMenu.Append("\n /    3 = Take a look around    \\");
            CantinaMenu = CantinaMenu.Append("\n \\    4 = Eat a ration          /");
            CantinaMenu = CantinaMenu.Append("\n /------------------------------\\");
            CantinaMenu = CantinaMenu.Append("\n \\    0 = Control Panel         /");
            CantinaMenu = CantinaMenu.Append("\n /-----------------------------\\\n");
            CantinaMenu = CantinaMenu.Append($"\n     Credits : {Character.ReturnCredits()}");
            CantinaMenu = CantinaMenu.Append($"\n      Health : {Character.ReturnHealth()}");
            CantinaMenu = CantinaMenu.Append($"\n   Ration(s) : {Character.ReturnRations()}");
            CantinaMenu = CantinaMenu.Append("\n \\~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~/");
            return CantinaMenu.ToString();
        }
    }
}
